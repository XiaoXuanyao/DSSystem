import llmopts
import fastapi
from pydantic import BaseModel, Field

class Api(fastapi.FastAPI):

    def __init__(self):
        super().__init__()
        self.llm = llmopts.LLM()

api = Api()



class Query(BaseModel):
    question: str = Field(
        ...,
        min_length=1,
        max_length=2000,
    )
    history: str = Field(
        ...,
        min_length=0,
        max_length=8000,
    )



@api.post("/query")
def query(
    body: Query,
):
    """
    查询函数，执行一次完整的查询流程，接受问题，返回查询结果
    """
    response = api.llm.query(
        question=body.question,
        history=body.history,
        n_results=3,
    )
    return {"response": response}